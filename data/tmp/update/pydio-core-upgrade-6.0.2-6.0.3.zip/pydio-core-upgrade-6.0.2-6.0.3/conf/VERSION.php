<?php
define("AJXP_VERSION", "6.0.3");
define("AJXP_VERSION_DATE", "2015-02-10");
define("AJXP_VERSION_REV", "3fe3764");
define("AJXP_VERSION_DB", "60");
