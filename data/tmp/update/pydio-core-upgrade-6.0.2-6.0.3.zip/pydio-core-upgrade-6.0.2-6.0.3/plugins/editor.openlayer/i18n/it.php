<?php

$mess=array(
"1" => "Mappa OpenLayers",
"2" => "Filtro",
"3" => "Posizione",
"4" => "Piani",
"5" => "Antialias",
"6" => "Formato",
"7" => "Stili",
"8" => "Filtra",
"9" => "Cerca",
"10" => "Pulisci",
);
