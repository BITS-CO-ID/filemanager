<?php
define("AJXP_VERSION", "6.0.4");
define("AJXP_VERSION_DATE", "2015-03-03");
define("AJXP_VERSION_REV", "b20d9b7");
define("AJXP_VERSION_DB", "60");
